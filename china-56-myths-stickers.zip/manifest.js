// 中国 56 个民族创世神话地图 · 56 族全量国风手绘贴纸清单
// 使用方式 A（推荐）：将本压缩包解压后，把 stickers 文件夹里的 56 张 .webp 图片全选拖入网页右上角「阶段 6 素材工坊」即可。
// 使用方式 B（便携文件夹）：在 HTML 同目录新建 assets 文件夹，把本包内的 manifest.js 和 stickers 文件夹放进 assets/ 目录即可。
window.MYTH_ASSETS = {
  stickers: ["han", "zhuang", "man", "hui", "miao", "uyghur", "tujia", "yi", "mongol", "zang", "buyi", "dong", "yao", "chaoxian", "bai", "hani", "kazakh", "li", "dai", "she", "lisu", "gelao", "dongxiang", "gaoshan", "lahu", "shui", "wa", "naxi", "qiang", "tu", "mulao", "xibe", "kirgiz", "daur", "jingpo", "maonan", "sala", "blang", "tajik", "achang", "pumi", "ewenki", "nu", "jing", "jino", "deang", "baoan", "russian", "yugur", "uzbek", "menba", "orqen", "dulong", "tatar", "hezhe", "luoba"],
  mandarinAudio: [],
  nativeAudio: []
};
